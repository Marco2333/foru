<?php
return array(
	//'配置项'=>'配置值'
	"ipUrl"=>"http://www.enjoyfu.com.cn/"
);