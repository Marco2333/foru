<?php
//000000000600a:2:{i:0;a:2:{s:7:"city_id";s:1:"1";s:9:"city_name";s:6:"苏州";}i:1;a:2:{s:7:"city_id";s:1:"2";s:9:"city_name";s:6:"南京";}}
?>