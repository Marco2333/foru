<?php
//000000000600a:2:{i:0;a:2:{s:9:"campus_id";s:1:"1";s:11:"campus_name";s:27:"苏州大学独墅湖校区";}i:1;a:2:{s:9:"campus_id";s:1:"2";s:11:"campus_name";s:18:"苏州大学本部";}}
?>