<?php
//000000000600a:1:{i:0;a:8:{s:11:"category_id";s:3:"105";s:9:"campus_id";s:1:"1";s:8:"category";s:12:"小优推荐";s:7:"img_url";N;s:9:"parent_id";s:1:"0";s:3:"tag";s:1:"1";s:6:"serial";s:1:"5";s:7:"is_open";s:1:"0";}}
?>